package hw6.src.geometricobject;

public interface GeometricObject {
	
	public double getArea();
	
	public double getPerimeter();
	
}
