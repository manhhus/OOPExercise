package hw6.src.resizable;

public interface Resizable {
	public void resize(int percent);

}
