package hw6.src.resizable;

public interface GeometricObject {
	public double getPerimeter();

	public double getArea();
}
