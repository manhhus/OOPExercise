package hw5.src.person;

public class TestMain {
    public static void main(String[] args) {
        Student stu1 = new Student("Sherlock", "221B duong Baker", "Cambridge", 100, 0);
        Staff sta1 = new Staff("Sherlock", "221B duong Baker", "Cambridge Highschool", 1);
        System.out.println(stu1);
        System.out.println(sta1);
    }
}